import java.io.Serializable;

public class AerosolNode implements Serializable {

	
	private static final long serialVersionUID = 2838477812618505501L;
	private String info;
	private int dosage;
	private AerosolNode left;
	private AerosolNode right;

	AerosolNode(int dosage, String info) {
		this.dosage = dosage;
		this.info = info;
		left = null;
		right = null;
	}

	public AerosolNode getLeft() {
		return left;
	}

	public void setLeft(AerosolNode left) {
		this.left = left;
	}

	public AerosolNode getRight() {
		return right;
	}

	public void setRight(AerosolNode right) {
		this.right = right;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public int getDosage() {
		return dosage;
	}

	public void setDosage(int dosage) {
		this.dosage = dosage;
	}

	public String inOrder(String string) {
		if (left != null)
			string = left.inOrder(string);
		String f =  "Dosage: "+ dosage + "\nInfo: " + info + "\n";
		string += f ;
		if (right != null)
			string = right.inOrder(string);
		return string;
	}

}
