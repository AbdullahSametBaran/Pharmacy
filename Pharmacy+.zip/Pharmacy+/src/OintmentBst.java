import java.io.Serializable;

public class OintmentBst implements Serializable {

	
	private static final long serialVersionUID = 1319871607247518495L;
	protected OintmentNode ointRoot;

	public OintmentBst() {
		ointRoot = null;
	}

	private OintmentNode createOintmentNode(int dosage, String info) {
		return new OintmentNode(dosage, info);
	}

	public OintmentNode getAeRoot() {
		return ointRoot;
	}

	public boolean insertToOintment(int Newdosage, String info) {
		if (ointRoot == null)
			ointRoot = createOintmentNode(Newdosage, info);
		else {
			OintmentNode parent = null;
			OintmentNode current = ointRoot;

			while (current != null) {
				if (Newdosage < current.getDosage()) {
					parent = current;
					current = current.getLeft();
				} else if (Newdosage > current.getDosage()) {
					parent = current;
					current = current.getRight();
				} else
					return false;
			}
			if (Newdosage < parent.getDosage())
				parent.setLeft(createOintmentNode(Newdosage, info));
			else
				parent.setRight(createOintmentNode(Newdosage, info));
		}

		return true;
	}

	public boolean deleteFromOintment(int Newdosage, String info) {
		OintmentNode parent = null;
		OintmentNode current = ointRoot;

		while (current != null) {
			if (Newdosage < current.getDosage()) {
				parent = current;
				current = current.getLeft();
			} else if (Newdosage > current.getDosage()) {
				parent = current;
				current = current.getRight();
			} else
				break;
		}
		if (current == null)
			return false;
		if (current.getLeft() == null) {
			if (parent == null) {
				if (ointRoot != null) {
					current.setInfo(null);
				}
				ointRoot = current.getRight();
			} else {
				if (Newdosage < parent.getDosage()) {
					if (ointRoot != null) {
						current.setInfo(null);

					}
					parent.setLeft(current.getRight());
				} else {

					if (ointRoot != null) {
						current.setInfo(null);
					}
					parent.setRight(current.getRight());
				}
			}
		} else {
			OintmentNode parentOfRightMost = current;
			OintmentNode rightMost = current.getLeft();
			while (rightMost.getRight() != null) {
				parentOfRightMost = rightMost;
				rightMost = rightMost.getRight();
			}
			if (ointRoot != null) {
				current.setInfo(null);
			}
			current.setDosage(rightMost.getDosage());
			if (parentOfRightMost.getRight() == rightMost) {
				if (ointRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setRight(rightMost.getLeft());
			} else {
				if (ointRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setLeft(rightMost.getLeft());
			}

		}
		return true;

	}

}
