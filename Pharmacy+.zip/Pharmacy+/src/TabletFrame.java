import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;

public class TabletFrame extends JFrame {

	private static final long serialVersionUID = 5947960050222364198L;
	private TabletBst tabletTree = new TabletBst();
	private JPanel contentPane;
	private JTextField txtDosage;
	private JTextField txtInfo;
	TabletNode tbNode;

	public TabletBst loadTablet() {

		tabletTree = new TabletBst();
		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream("Tablet.txt"));
			try {
				tabletTree = (TabletBst) in.readObject();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tabletTree;
	}

	public void saveTablet(TabletBst tabletTree) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Tablet.txt"));
			oos.writeObject(tabletTree);
			oos.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TabletFrame frame = new TabletFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TabletFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 684, 505);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Tablet");

		JLabel lblDosage = new JLabel("Dosage");
		lblDosage.setFont(new Font("Tw Cen MT", Font.BOLD, 15));
		lblDosage.setBounds(10, 31, 60, 19);
		contentPane.add(lblDosage);

		txtDosage = new JTextField();
		txtDosage.setBackground(new Color(255, 204, 255));
		txtDosage.setBounds(10, 55, 96, 19);
		contentPane.add(txtDosage);
		txtDosage.setColumns(10);

		JLabel lblInformation = new JLabel("Information");
		lblInformation.setFont(new Font("Tw Cen MT", Font.BOLD, 15));
		lblInformation.setBounds(10, 85, 96, 28);
		contentPane.add(lblInformation);

		txtInfo = new JTextField();
		txtInfo.setBackground(new Color(204, 255, 255));
		txtInfo.setBounds(10, 112, 169, 185);
		contentPane.add(txtInfo);
		txtInfo.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(442, 55, 216, 400);
		contentPane.add(scrollPane);

		JEditorPane lastInfo = new JEditorPane();
		lastInfo.setBackground(new Color(224, 255, 255));
		scrollPane.setViewportView(lastInfo);
		lastInfo.setEditable(false);

		JButton btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Tw Cen MT", Font.BOLD, 13));
		btnAdd.setBackground(new Color(255, 250, 240));
		btnAdd.setForeground(new Color(0, 0, 0));

		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dosage = Integer.parseInt(txtDosage.getText());
				String info = txtInfo.getText();
				tabletTree.insertToTablet(dosage, info);

				tabletTree = loadTablet();

				tbNode = tabletTree.getTabRoot();

				tabletTree.insertToTablet(dosage, info);
				saveTablet(tabletTree);

				try {
					lastInfo.setText(tbNode.inOrder(""));
				} catch (NullPointerException e1) {
					System.out.println("First item has been added.\nJust click the display button to show your item");
					e1.printStackTrace();
				}

			}
		});

		btnAdd.setBounds(10, 310, 85, 21);
		contentPane.add(btnAdd);

		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Tw Cen MT", Font.BOLD, 13));
		btnDelete.setBackground(new Color(255, 250, 240));
		btnDelete.setForeground(new Color(0, 0, 0));

		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int dosage = Integer.parseInt(txtDosage.getText());
				String info = txtInfo.getText();
				tabletTree.deleteFromTablet(dosage, info);

				tabletTree = loadTablet();

				tbNode = tabletTree.getTabRoot();

				tabletTree.deleteFromTablet(dosage, info);
				saveTablet(tabletTree);

				try {
					lastInfo.setText(tbNode.inOrder(""));
				} catch (NullPointerException e1) {
					System.out.println("No item for deletion process");
					e1.printStackTrace();
				}

			}
		});
		btnDelete.setBounds(105, 310, 85, 21);
		contentPane.add(btnDelete);

		JButton btnDisplayList = new JButton("Display List");
		btnDisplayList.setFont(new Font("Tw Cen MT", Font.BOLD, 13));
		btnDisplayList.setBackground(new Color(255, 250, 240));
		btnDisplayList.setForeground(new Color(0, 0, 0));
		btnDisplayList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				tabletTree = loadTablet();

				tbNode = tabletTree.getTabRoot();

				try {
					lastInfo.setText(tbNode.inOrder(""));
				} catch (NullPointerException e1) {
					System.out.println("No item for displaying process");
					e1.printStackTrace();
				}
			}
		});
		btnDisplayList.setBounds(34, 351, 122, 23);
		contentPane.add(btnDisplayList);

		JLabel lblTheListOf = new JLabel("The List");
		lblTheListOf.setForeground(Color.BLACK);
		lblTheListOf.setFont(new Font("Tw Cen MT", Font.BOLD, 16));
		lblTheListOf.setBounds(455, 25, 69, 28);
		contentPane.add(lblTheListOf);

		JLabel imageLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("TabletImage.png")).getImage();
		imageLabel.setIcon(new ImageIcon(img));
		imageLabel.setBounds(0, 0, 668, 466);
		contentPane.add(imageLabel);
	}
}
