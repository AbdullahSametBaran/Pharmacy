import java.io.Serializable;

public class CreamBst implements Serializable {

	private static final long serialVersionUID = 4648593640269879064L;
	protected CreamNode creRoot;

	public CreamBst() {
		creRoot = null;
	}

	private CreamNode createCreamNode(int dosage, String info) {
		return new CreamNode(dosage, info);
	}

	public CreamNode getCreRoot() {
		return creRoot;
	}

	public boolean insertToCream(int Newdosage, String info) {
		if (creRoot == null)
			creRoot = createCreamNode(Newdosage, info);
		else {
			CreamNode parent = null;
			CreamNode current = creRoot;

			while (current != null) {
				if (Newdosage < current.getDosage()) {
					parent = current;
					current = current.getLeft();
				} else if (Newdosage > current.getDosage()) {
					parent = current;
					current = current.getRight();
				} else
					return false;
			}
			if (Newdosage < parent.getDosage())
				parent.setLeft(createCreamNode(Newdosage, info));
			else
				parent.setRight(createCreamNode(Newdosage, info));
		}

		return true;
	}

	public boolean deleteFromCream(int Newdosage, String info) {
		CreamNode parent = null;
		CreamNode current = creRoot;

		while (current != null) {
			if (Newdosage < current.getDosage()) {
				parent = current;
				current = current.getLeft();
			} else if (Newdosage > current.getDosage()) {
				parent = current;
				current = current.getRight();
			} else
				break;
		}
		if (current == null)
			return false;
		if (current.getLeft() == null) {
			if (parent == null) {
				if (creRoot != null) {
					current.setInfo(null);
				}
				creRoot = current.getRight();
			} else {
				if (Newdosage < parent.getDosage()) {
					if (creRoot != null) {
						current.setInfo(null);

					}
					parent.setLeft(current.getRight());
				} else {

					if (creRoot != null) {
						current.setInfo(null);
					}
					parent.setRight(current.getRight());
				}
			}
		} else {
			CreamNode parentOfRightMost = current;
			CreamNode rightMost = current.getLeft();
			while (rightMost.getRight() != null) {
				parentOfRightMost = rightMost;
				rightMost = rightMost.getRight();
			}
			if (creRoot != null) {
				current.setInfo(null);
			}
			current.setDosage(rightMost.getDosage());
			if (parentOfRightMost.getRight() == rightMost) {
				if (creRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setRight(rightMost.getLeft());
			} else {
				if (creRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setLeft(rightMost.getLeft());
			}

		}
		return true;

	}

}
