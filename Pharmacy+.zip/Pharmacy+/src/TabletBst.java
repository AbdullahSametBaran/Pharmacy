import java.io.Serializable;

public class TabletBst implements Serializable {

	private static final long serialVersionUID = -7110590883015512728L;
	protected TabletNode tabRoot;

	public TabletBst() {
		tabRoot = null;
	}

	private TabletNode createTabletNode(int dosage, String info) {
		return new TabletNode(dosage, info);
	}

	public TabletNode getTabRoot() {
		return tabRoot;
	}

	public boolean insertToTablet(int Newdosage, String info) {
		if (tabRoot == null)
			tabRoot = createTabletNode(Newdosage, info);
		else {
			TabletNode parent = null;
			TabletNode current = tabRoot;

			while (current != null) {
				if (Newdosage < current.getDosage()) {
					parent = current;
					current = current.getLeft();
				} else if (Newdosage > current.getDosage()) {
					parent = current;
					current = current.getRight();
				} else
					return false;
			}
			if (Newdosage < parent.getDosage())
				parent.setLeft(createTabletNode(Newdosage, info));
			else
				parent.setRight(createTabletNode(Newdosage, info));
		}

		return true;
	}

	public boolean deleteFromTablet(int Newdosage, String info) {
		TabletNode parent = null;
		TabletNode current = tabRoot;

		while (current != null) {
			if (Newdosage < current.getDosage()) {
				parent = current;
				current = current.getLeft();
			} else if (Newdosage > current.getDosage()) {
				parent = current;
				current = current.getRight();
			} else
				break;
		}
		if (current == null)
			return false;
		if (current.getLeft() == null) {
			if (parent == null) {
				if (tabRoot != null) {
					current.setInfo(null);
				}
				tabRoot = current.getRight();
			} else {
				if (Newdosage < parent.getDosage()) {
					if (tabRoot != null) {
						current.setInfo(null);

					}
					parent.setLeft(current.getRight());
				} else {

					if (tabRoot != null) {
						current.setInfo(null);
					}
					parent.setRight(current.getRight());
				}
			}
		} else {
			TabletNode parentOfRightMost = current;
			TabletNode rightMost = current.getLeft();
			while (rightMost.getRight() != null) {
				parentOfRightMost = rightMost;
				rightMost = rightMost.getRight();
			}
			if (tabRoot != null) {
				current.setInfo(null);
			}
			current.setDosage(rightMost.getDosage());
			if (parentOfRightMost.getRight() == rightMost) {
				if (tabRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setRight(rightMost.getLeft());
			} else {
				if (tabRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setLeft(rightMost.getLeft());
			}

		}
		return true;

	}

}
