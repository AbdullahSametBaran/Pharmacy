import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.UIManager;

public class CapsuleFrame extends JFrame {

	private static final long serialVersionUID = -864191155898598925L;
	private CapsuleBst capsuleTree = new CapsuleBst();
	private JPanel contentPane;
	private JTextField txtDosage;
	private JTextField txtInfo;
	CapsuleNode cpNode;

	public CapsuleBst loadCapsule() {

		capsuleTree = new CapsuleBst();
		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream("Capsule.txt"));
			try {
				capsuleTree = (CapsuleBst) in.readObject();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return capsuleTree;
	}

	public void saveCapsule(CapsuleBst capsuleTree) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Capsule.txt"));
			oos.writeObject(capsuleTree);
			oos.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CapsuleFrame frame = new CapsuleFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CapsuleFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 684, 505);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Capsule");

		JLabel lblDosage = new JLabel("Dosage");
		lblDosage.setFont(new Font("Tw Cen MT", Font.BOLD, 15));
		lblDosage.setBounds(10, 31, 60, 19);
		contentPane.add(lblDosage);

		txtDosage = new JTextField();
		txtDosage.setBackground(new Color(255, 204, 255));
		txtDosage.setBounds(10, 55, 96, 19);
		contentPane.add(txtDosage);
		txtDosage.setColumns(10);

		JLabel lblInformation = new JLabel("Information");
		lblInformation.setFont(new Font("Tw Cen MT", Font.BOLD, 15));
		lblInformation.setBounds(10, 85, 96, 28);
		contentPane.add(lblInformation);

		txtInfo = new JTextField();
		txtInfo.setBackground(new Color(204, 255, 255));
		txtInfo.setBounds(10, 112, 169, 185);
		contentPane.add(txtInfo);
		txtInfo.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(442, 55, 216, 400);
		contentPane.add(scrollPane);

		JEditorPane lastInfo = new JEditorPane();
		lastInfo.setBackground(new Color(224, 255, 255));
		scrollPane.setViewportView(lastInfo);
		lastInfo.setEditable(false);

		JButton btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Tw Cen MT", Font.BOLD, 13));
		btnAdd.setBackground(new Color(0, 153, 204));
		btnAdd.setForeground(new Color(0, 0, 0));

		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dosage = Integer.parseInt(txtDosage.getText());
				String info = txtInfo.getText();
				capsuleTree.insertToCapsule(dosage, info);

				capsuleTree = loadCapsule();

				cpNode = capsuleTree.getCapRoot();

				capsuleTree.insertToCapsule(dosage, info);
				saveCapsule(capsuleTree);

				try {
					lastInfo.setText(cpNode.inOrder(""));
				} catch (NullPointerException e1) {
					System.out.println("First item has been added.\nJust click the display button to show your item");
					e1.printStackTrace();
				}

			}
		});

		btnAdd.setBounds(10, 310, 85, 21);
		contentPane.add(btnAdd);

		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Tw Cen MT", Font.BOLD, 13));
		btnDelete.setBackground(new Color(0, 153, 204));
		btnDelete.setForeground(new Color(0, 0, 0));

		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int dosage = Integer.parseInt(txtDosage.getText());
				String info = txtInfo.getText();
				capsuleTree.deleteFromCapsule(dosage, info);

				capsuleTree = loadCapsule();

				cpNode = capsuleTree.getCapRoot();

				capsuleTree.deleteFromCapsule(dosage, info);
				saveCapsule(capsuleTree);

				try {
					lastInfo.setText(cpNode.inOrder(""));
				} catch (NullPointerException e) {
					System.out.println("No item for deletion process");
					e.printStackTrace();
				}

			}
		});
		btnDelete.setBounds(105, 310, 85, 21);
		contentPane.add(btnDelete);

		JButton btnDisplayList = new JButton("Display List");
		btnDisplayList.setFont(new Font("Tw Cen MT", Font.BOLD, 13));
		btnDisplayList.setBackground(new Color(0, 153, 204));
		btnDisplayList.setForeground(new Color(0, 0, 0));
		btnDisplayList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				capsuleTree = loadCapsule();

				cpNode = capsuleTree.getCapRoot();

				try {
					lastInfo.setText(cpNode.inOrder(""));
				} catch (NullPointerException e) {
					System.out.println("No item for displaying process");
					e.printStackTrace();
				}
			}
		});
		btnDisplayList.setBounds(34, 351, 122, 23);
		contentPane.add(btnDisplayList);

		JLabel lblTheListOf = new JLabel("The List");
		lblTheListOf.setForeground(Color.BLACK);
		lblTheListOf.setFont(new Font("Tw Cen MT", Font.BOLD, 16));
		lblTheListOf.setBounds(455, 25, 69, 28);
		contentPane.add(lblTheListOf);

		JLabel imageLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("CapsuleImage.png")).getImage();
		imageLabel.setIcon(new ImageIcon(img));
		imageLabel.setBounds(0, 0, 668, 466);
		contentPane.add(imageLabel);

	}
}
