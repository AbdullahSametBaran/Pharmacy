import java.io.Serializable;

public class AerosolBst implements Serializable {

	private static final long serialVersionUID = 3722114257924223222L;
	protected AerosolNode aeRoot;

	public AerosolBst() {
		aeRoot = null;
	}

	private AerosolNode createAerosolNode(int dosage, String info) {
		return new AerosolNode(dosage, info);
	}

	public AerosolNode getAeRoot() {
		return aeRoot;
	}

	public boolean insertToAerosol(int Newdosage, String info) {
		if (aeRoot == null)
			aeRoot = createAerosolNode(Newdosage, info);
		else {
			AerosolNode parent = null;
			AerosolNode current = aeRoot;

			while (current != null) {
				if (Newdosage < current.getDosage()) {
					parent = current;
					current = current.getLeft();
				} else if (Newdosage > current.getDosage()) {
					parent = current;
					current = current.getRight();
				} else
					return false;
			}
			if (Newdosage < parent.getDosage())
				parent.setLeft(createAerosolNode(Newdosage, info));
			else
				parent.setRight(createAerosolNode(Newdosage, info));
		}

		return true;
	}

	public boolean deleteFromAerosol(int Newdosage, String info) {
		AerosolNode parent = null;
		AerosolNode current = aeRoot;

		while (current != null) {
			if (Newdosage < current.getDosage()) {
				parent = current;
				current = current.getLeft();
			} else if (Newdosage > current.getDosage()) {
				parent = current;
				current = current.getRight();
			} else
				break;
		}
		if (current == null)
			return false;
		if (current.getLeft() == null) {
			if (parent == null) {
				if (aeRoot != null) {
					current.setInfo(null);
				}
				aeRoot = current.getRight();
			} else {
				if (Newdosage < parent.getDosage()) {
					if (aeRoot != null) {
						current.setInfo(null);

					}
					parent.setLeft(current.getRight());
				} else {

					if (aeRoot != null) {
						current.setInfo(null);
					}
					parent.setRight(current.getRight());
				}
			}
		} else {
			AerosolNode parentOfRightMost = current;
			AerosolNode rightMost = current.getLeft();
			while (rightMost.getRight() != null) {
				parentOfRightMost = rightMost;
				rightMost = rightMost.getRight();
			}
			if (aeRoot != null) {
				current.setInfo(null);
			}
			current.setDosage(rightMost.getDosage());
			if (parentOfRightMost.getRight() == rightMost) {
				if (aeRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setRight(rightMost.getLeft());
			} else {
				if (aeRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setLeft(rightMost.getLeft());
			}

		}
		return true;

	}

}
