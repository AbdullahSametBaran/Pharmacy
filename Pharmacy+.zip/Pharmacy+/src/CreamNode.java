import java.io.Serializable;

public class CreamNode implements Serializable {

	private static final long serialVersionUID = -8576480594317495069L;
	private String info;
	private int dosage;
	private CreamNode left;
	private CreamNode right;

	public CreamNode(int dosage, String info) {
		this.dosage = dosage;
		this.info = info;
		left = null;
		right = null;
	}

	public CreamNode getLeft() {
		return left;
	}

	public void setLeft(CreamNode left) {
		this.left = left;
	}

	public CreamNode getRight() {
		return right;
	}

	public void setRight(CreamNode right) {
		this.right = right;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public int getDosage() {
		return dosage;
	}

	public void setDosage(int dosage) {
		this.dosage = dosage;
	}

	public String toStringCream() {
		return "Drug Dosage: " + dosage + "\nDrug Information " + info;
	}

	public String inOrder(String string) {
		if (left != null)
			string = left.inOrder(string);
		String f = "Dosage: " + dosage + "\nInfo: " + info + "\n";
		string += f;
		if (right != null)
			string = right.inOrder(string);
		return string;
	}

}
