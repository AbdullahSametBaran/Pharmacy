import java.io.Serializable;

public class CapsuleNode implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = -8791800334550797019L;
	private String info;
	private int dosage;
	private CapsuleNode left;
	private CapsuleNode right;

	public CapsuleNode(int dosage, String info) {
		this.dosage = dosage;
		this.info = info;
		left = null;
		right = null;
	}

	public CapsuleNode getLeft() {
		return left;
	}

	public void setLeft(CapsuleNode left) {
		this.left = left;
	}

	public CapsuleNode getRight() {
		return right;
	}

	public void setRight(CapsuleNode right) {
		this.right = right;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public int getDosage() {
		return dosage;
	}

	public void setDosage(int dosage) {
		this.dosage = dosage;
	}

	public String toStringCapsule() {
		return "Drug Dosage: " + dosage + "\nDrug Information " + info;
	}

	public String inOrder(String string) {
		if (left != null)
			string = left.inOrder(string);
		String f = "Dosage: " + dosage + "\nInfo: " + info + "\n";
		string += f;
		if (right != null)
			string = right.inOrder(string);
		return string;
	}

}
