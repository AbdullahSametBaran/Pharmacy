import java.io.Serializable;

public class TabletNode implements Serializable {

	private String info;
	private int dosage;
	private TabletNode left;
	private TabletNode right;

	public TabletNode(int dosage, String info) {
		this.dosage = dosage;
		this.info = info;
		left = null;
		right = null;
	}

	public TabletNode getLeft() {
		return left;
	}

	public void setLeft(TabletNode left) {
		this.left = left;
	}

	public TabletNode getRight() {
		return right;
	}

	public void setRight(TabletNode right) {
		this.right = right;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public int getDosage() {
		return dosage;
	}

	public void setDosage(int dosage) {
		this.dosage = dosage;
	}

	public String toStringTablet() {
		return "Drug Dosage: " + dosage + "\nDrug Information " + info;
	}
	
	public String inOrder(String string) {
        if (left != null)
            string = left.inOrder(string);
        String f =  "Dosage: "+ dosage + "\nInfo: " + info + "\n";
        string += f ;
        if (right != null)
            string = right.inOrder(string);
        return string;
    }

}
