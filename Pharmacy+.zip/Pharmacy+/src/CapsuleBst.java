
import java.io.Serializable;

public class CapsuleBst implements Serializable {

	private static final long serialVersionUID = 1182397733244123131L;
	protected CapsuleNode capRoot;

	public CapsuleBst() {
		capRoot = null;
	}

	private CapsuleNode createCapsuleNode(int dosage, String info) {
		return new CapsuleNode(dosage, info);
	}

	public CapsuleNode getCapRoot() {
		return capRoot;
	}

	public boolean insertToCapsule(int Newdosage, String info) {
		if (capRoot == null)
			capRoot = createCapsuleNode(Newdosage, info);
		else {
			CapsuleNode parent = null;
			CapsuleNode current = capRoot;

			while (current != null) {
				if (Newdosage < current.getDosage()) {
					parent = current;
					current = current.getLeft();
				} else if (Newdosage > current.getDosage()) {
					parent = current;
					current = current.getRight();
				} else
					return false;
			}
			if (Newdosage < parent.getDosage())
				parent.setLeft(createCapsuleNode(Newdosage, info));
			else
				parent.setRight(createCapsuleNode(Newdosage, info));
		}

		return true;
	}

	public boolean deleteFromCapsule(int Newdosage, String info) {
		CapsuleNode parent = null;
		CapsuleNode current = capRoot;

		while (current != null) {
			if (Newdosage < current.getDosage()) {
				parent = current;
				current = current.getLeft();
			} else if (Newdosage > current.getDosage()) {
				parent = current;
				current = current.getRight();
			} else
				break;
		}
		if (current == null)
			return false;
		if (current.getLeft() == null) {
			if (parent == null) {
				if (capRoot != null) {
					current.setInfo(null);
				}
				capRoot = current.getRight();
			} else {
				if (Newdosage < parent.getDosage()) {
					if (capRoot != null) {
						current.setInfo(null);

					}
					parent.setLeft(current.getRight());
				} else {

					if (capRoot != null) {
						current.setInfo(null);
					}
					parent.setRight(current.getRight());
				}
			}
		} else {
			CapsuleNode parentOfRightMost = current;
			CapsuleNode rightMost = current.getLeft();
			while (rightMost.getRight() != null) {
				parentOfRightMost = rightMost;
				rightMost = rightMost.getRight();
			}
			if (capRoot != null) {
				current.setInfo(null);
			}
			current.setDosage(rightMost.getDosage());
			if (parentOfRightMost.getRight() == rightMost) {
				if (capRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setRight(rightMost.getLeft());
			} else {
				if (capRoot != null) {
					current.setInfo(null);
				}
				parentOfRightMost.setLeft(rightMost.getLeft());
			}

		}
		return true;

	}

}
