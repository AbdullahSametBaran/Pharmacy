import java.io.Serializable;

public class OintmentNode extends OintmentBst implements Serializable {

	private String info;
	private int dosage;
	private OintmentNode left;
	private OintmentNode right;

	OintmentNode(int dosage, String info) {
		this.dosage = dosage;
		this.info = info;
		left = null;
		right = null;
	}

	public OintmentNode getLeft() {
		return left;
	}

	public void setLeft(OintmentNode left) {
		this.left = left;
	}

	public OintmentNode getRight() {
		return right;
	}

	public void setRight(OintmentNode right) {
		this.right = right;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public int getDosage() {
		return dosage;
	}

	public void setDosage(int dosage) {
		this.dosage = dosage;
	}

	public String inOrder(String string) {
		
		if (left != null)
			string = left.inOrder(string);

		String f = "Dosage: " + dosage + "\nInfo: " + info + "\n";
		string += f;

		if (right != null)
			string = right.inOrder(string);
		return string;
	}

}
