import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

public class HomePageActivity extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7345549793664158171L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePageActivity frame = new HomePageActivity();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomePageActivity() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 547, 351);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Pharmacy+");

		JButton btnAerosol = new JButton("AEROSOL");
		btnAerosol.setForeground(new Color(0, 153, 255));
		btnAerosol.setBackground(new Color(0, 0, 0));
		btnAerosol.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		btnAerosol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AerosolFrame aframe = new AerosolFrame();
				aframe.setVisible(true);
				aframe.setDefaultCloseOperation(HIDE_ON_CLOSE);
			}
		});
		btnAerosol.setBounds(409, 239, 100, 40);
		contentPane.add(btnAerosol);

		JButton btnCapsule = new JButton("CAPSULE");
		btnCapsule.setForeground(new Color(0, 153, 255));
		btnCapsule.setBackground(new Color(0, 0, 0));
		btnCapsule.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		btnCapsule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CapsuleFrame caframe = new CapsuleFrame();
				caframe.setVisible(true);
				caframe.setDefaultCloseOperation(HIDE_ON_CLOSE);
			}
		});
		btnCapsule.setBounds(309, 198, 100, 40);
		contentPane.add(btnCapsule);

		JButton btnCream = new JButton("CREAM");
		btnCream.setForeground(new Color(0, 153, 255));
		btnCream.setBackground(new Color(0, 0, 0));
		btnCream.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 11));
		btnCream.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CreamFrame crframe = new CreamFrame();
				crframe.setVisible(true);
				crframe.setDefaultCloseOperation(HIDE_ON_CLOSE);
			}
		});
		btnCream.setBounds(110, 198, 100, 40);
		contentPane.add(btnCream);

		JButton btnOintment = new JButton("OINTMENT");
		btnOintment.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 11));
		btnOintment.setForeground(new Color(0, 153, 255));
		btnOintment.setBackground(new Color(0, 0, 0));
		btnOintment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OintmentFrame oframe = new OintmentFrame();
				oframe.setVisible(true);
				oframe.setDefaultCloseOperation(HIDE_ON_CLOSE);
			}
		});
		btnOintment.setBounds(10, 239, 100, 40);
		contentPane.add(btnOintment);

		JButton btnTablet = new JButton("TABLET");
		btnTablet.setForeground(new Color(0, 153, 255));
		btnTablet.setBackground(new Color(0, 0, 0));
		btnTablet.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 11));
		btnTablet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TabletFrame tframe = new TabletFrame();
				tframe.setVisible(true);
				tframe.setDefaultCloseOperation(HIDE_ON_CLOSE);
			}
		});
		btnTablet.setBounds(210, 239, 100, 40);
		contentPane.add(btnTablet);

		JButton btnNewButton = new JButton("Healthcare Panel");
		btnNewButton.setForeground(new Color(255, 153, 255));
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Tw Cen MT", Font.BOLD, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				HealthcareFrame daframe = new HealthcareFrame();
				daframe.setVisible(true);
				daframe.setDefaultCloseOperation(HIDE_ON_CLOSE);
			}
		});
		btnNewButton.setBounds(386, 25, 135, 25);
		contentPane.add(btnNewButton);

		JLabel lblNewLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("PharmacyImage.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(0, 0, 531, 312);
		contentPane.add(lblNewLabel);
	}
}
